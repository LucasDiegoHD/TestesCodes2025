## Welcome to the Offical Pedro Pathing Quickstart!  

Follow the steps on our [website](https://pedropathing.com/) to tune and setup!  
Feel Free to reach out on the [Offical Pedro Pathing Discord Server](https://discord.gg/2GfC4qBP5s)!
