package pedroPathing.localization;

public enum Localizers {
    DRIVE_ENCODERS,
    TWO_WHEEL,
    THREE_WHEEL,
    THREE_WHEEL_IMU,
    OTOS,
    PINPOINT
}
